package com.example.examprep.db.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Country (
    @PrimaryKey val uid: Int,
    @ColumnInfo(name = "name") var name: String,
    @ColumnInfo(name = "capital") var capital: String,
    @ColumnInfo(name = "flag") var flag: String
)