package com.example.examprep.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.examprep.db.dao.CountryDao
import com.example.examprep.db.entity.Country

@Database(entities = [Country::class], version = 1)
abstract class AppDatabase: RoomDatabase() {
    abstract fun countryDao(): CountryDao
}