package com.example.examprep.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.examprep.adapter.CountryAdapter
import com.example.examprep.databinding.ActivityMainBinding
import com.example.examprep.factory.CountryViewModelFactory
import com.example.examprep.model.CountryResponse
import com.example.examprep.repository.CountryRepository
import com.example.examprep.service.CountryService
import com.example.examprep.viewmodel.CountryViewModel
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var countryService: CountryService
    private lateinit var countryRepository: CountryRepository
    lateinit var countryViewModel: CountryViewModel

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://restcountries.com/v2/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        init()
        observeData()

        countryViewModel.getCountries()
    }

    private fun init() {
        countryService = retrofit.create(CountryService::class.java)
        countryRepository = CountryRepository(countryService)
        val countryViewModelFactory = CountryViewModelFactory(countryRepository)
        countryViewModel = ViewModelProvider(this, countryViewModelFactory)[CountryViewModel::class.java]
    }

    private fun observeData() {
        GlobalScope.launch {
            countryViewModel.countriesList.collect {
                runOnUiThread {
                    val adapter = CountryAdapter(it)
                    binding.countriesList.adapter = adapter
                    binding.tvCountriesCount.text = "Countries: ${it.size}"
                }
            }
        }
    }
}