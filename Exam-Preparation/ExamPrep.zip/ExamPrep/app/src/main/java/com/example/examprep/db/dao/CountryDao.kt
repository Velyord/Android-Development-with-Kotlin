package com.example.examprep.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.examprep.db.entity.Country
import com.example.examprep.model.CountryResponse

@Dao
interface CountryDao {
    //@Query("SELECT * FROM countries")
    //suspend fun getCountries(): List<Country>

    @Insert
    suspend fun insertAll(countries: List<Country>)
}