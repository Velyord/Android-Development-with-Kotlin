package com.example.examprep.factory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.examprep.repository.CountryRepository
import com.example.examprep.viewmodel.CountryViewModel

class CountryViewModelFactory(
    private val countryRepository: CountryRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return CountryViewModel(countryRepository) as T
    }
}