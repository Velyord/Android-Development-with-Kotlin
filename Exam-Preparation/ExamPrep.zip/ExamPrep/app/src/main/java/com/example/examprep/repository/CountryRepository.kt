package com.example.examprep.repository

import com.example.examprep.model.CountryDetailResponse
import com.example.examprep.model.CountryResponse
import com.example.examprep.service.CountryService
import retrofit2.Call

class CountryRepository constructor(
    private val countryService: CountryService
) {
    fun getCountries(): Call<List<CountryResponse>>? {
        return try {
            val countries = countryService.getCountries()
            countries
        } catch (e: Exception) {
            // an error occurred, handle and act accordingly
            null
        }
    }

    fun getCountryByName(name: String): Call<List<CountryDetailResponse>>? {
        return try {
            val countries = countryService.getCountryByName(name)
            countries
        } catch (e: Exception) {
            // an error occurred, handle and act accordingly
            null
        }
    }
}