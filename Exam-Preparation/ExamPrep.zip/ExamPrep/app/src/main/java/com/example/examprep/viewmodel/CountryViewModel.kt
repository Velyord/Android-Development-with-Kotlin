package com.example.examprep.viewmodel

import androidx.lifecycle.ViewModel
import com.example.examprep.adapter.CountryAdapter
import com.example.examprep.model.CountryDetailResponse
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.example.examprep.model.CountryResponse
import com.example.examprep.repository.CountryRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CountryViewModel(
    private val countryRepository: CountryRepository
) : ViewModel() {
    private val countriesListStateFlow = MutableStateFlow<List<CountryResponse>>(arrayListOf())
    private val selectedCountryStateFlow = MutableStateFlow<CountryDetailResponse?>(null)

    val countriesList: StateFlow<List<CountryResponse>> = countriesListStateFlow.asStateFlow()
    val selectedCountry: StateFlow<CountryDetailResponse?> = selectedCountryStateFlow.asStateFlow()

    fun getCountries() {
        countryRepository.getCountries()?.enqueue(object : Callback<List<CountryResponse>> {
            override fun onResponse(call: Call<List<CountryResponse>>, response: Response<List<CountryResponse>>) {
                val countries = response.body() ?: return
                countriesListStateFlow.value = countries.sortedBy {it.name}
                // val adapter = CountryAdapter(countries)
                // binding.countriesList.adapter = adapter
            }

            override fun onFailure(call: Call<List<CountryResponse>>, t: Throwable) {
                // log error message
                // show error to user
                val error = 42;
            }
        })
    }

    fun getCountryByName(name: String) {
        countryRepository.getCountryByName(name)?.enqueue(object: Callback<List<CountryDetailResponse>>{
            override fun onResponse(
                call: Call<List<CountryDetailResponse>>,
                response: Response<List<CountryDetailResponse>>
            ) {
                val countries = response.body() ?: return
                selectedCountryStateFlow.value = countries.firstOrNull()
            }

            override fun onFailure(call: Call<List<CountryDetailResponse>>, t: Throwable) {
                //
            }
        })
    }
}