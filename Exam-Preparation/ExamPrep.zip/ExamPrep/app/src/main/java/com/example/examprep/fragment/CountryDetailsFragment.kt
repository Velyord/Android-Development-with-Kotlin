package com.example.examprep.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.examprep.activity.MainActivity
import com.example.examprep.databinding.FragmentCountryDetailsBinding
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class CountryDetailsFragment: Fragment() {

    private lateinit var binding: FragmentCountryDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val selectedCountryName = arguments?.getString("country_name", null)
        (activity as MainActivity).countryViewModel.getCountryByName(selectedCountryName ?: return)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCountryDetailsBinding.inflate(LayoutInflater.from(context))
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        observeData()
    }

    private fun observeData() {
        GlobalScope.launch {
            (activity as MainActivity).countryViewModel.selectedCountry.collect {
                binding.country = it
            }
        }
    }
}